#!/bin/sh

# wget -L https://www.mongodbmanager.com/files/mongodbmanagerfree_inst.exe
#docker run -d --tty --rm --name test-connect-mongo-2 mongo:3.6.17-xenial\
#    mongo --host $(sh ./docker-machine-ip.sh):27017
#jdbc:h2:tcp://localhost:65123/./flow-centric-poc-db;AUTO_RECONNECT=TRUE