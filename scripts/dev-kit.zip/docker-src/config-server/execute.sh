#!/bin/bash
echo "Executing command: $@"
eval "$@"