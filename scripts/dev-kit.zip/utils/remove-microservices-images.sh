#!/bin/sh
docker image ls|grep -v TAG|grep 1.0.0-flow-centric|awk 'BEGON {FS=OFS=" "}{print $3}'|xargs docker rmi
