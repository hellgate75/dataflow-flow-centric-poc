#!/bin/sh -e
CURRDIR="$(dirname "$(realpath "$0")")"
FILE_LIST="$(ls $CURRDIR/ 2> /dev/null|xargs echo )"
if [[ "" == "$(echo $PATH | grep ":$CURRDIR")" ]]; then
	PATH="$PATH:$CURRDIR"
fi
VBOXMAN_PATH="c:\\Program Files\\Oracle\\VirtualBox\\vboxmanage"
if [[ "" == "$(ls "$VBOXMAN_PATH" 2> /dev/null )" ]]; then
	echo "Please install Oracle VirtualBox v. 6.1 in order to instal docker!!"
	echo "Try with experimental script: install-virtualbox.sh"
	exit 1
fi
echo "Uninstalling Docker packages..."
if [[ "" != "$(which docker-machine-cmd.exe 2> /dev/null)" ]]; then
	if [[ "" != "$(docker-machine-cmd.exe ls | grep "default ")" ]]; then
		if [[ "" != "$(docker-machine-cmd.exe status default | grep Running)" ]]; then
				echo "Stopping default docker VirtualBox vm"
				docker-machine-cmd.exe stop default
				sleep 1
		fi
		echo "Removing default docker VirtualBox vm"
		docker-machine-cmd.exe rm -f -y default
		sleep 2
	fi
else
	echo "Command docker-machine is not present, cannot delete the vm."
	echo "Please delete the 'default' vm via VirtualBox GUI."
fi
echo "Removing residual files ..."
IFS=" ";for file in $FILE_LIST; do
     if [[ "install-docker.sh" != "$file" ]] && [[ "uninstall-docker.sh" != "$file" ]] && [[ "install-virtualbox.sh" != "$file" ]] && [[ "env.bat" != "$file" ]]; then
	    sh -c "rm -rf $CURRDIR/$file 2> /dev/null "
		if [[ -e "$CURRDIR"/$file ]]; then
		   sh -c "rm -Rf $CURRDIR/$file 2> /dev/null "
		fi
		echo "Removed file $file."
	 fi
done

echo "Docker uninstall complete!!"
