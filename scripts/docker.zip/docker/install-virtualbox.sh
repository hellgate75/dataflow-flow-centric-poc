#!/bin/sh -e

CURRDIR="$(pwd)"
VIRBOX_REL="6.1.2"
VIRBOX_SUB_REL="135663"
VBOXMAN_PATH="C:\\Program Files\\Oracle\\VirtualBox\\vboxmanage"
VIRBOX_PATH="C:\\Program Files\\Oracle\\VirtualBox"
EXTPACK_NAME="Oracle_VM_VirtualBox_Extension_Pack-$VIRBOX_REL.vbox-extpack"


if [[ "" == "$(ls "$CURRDIR"/VirtualBox-$VIRBOX_REL-$VIRBOX_SUB_REL-Win.exe 2> /dev/null )" ]]; then
	curl -L https://download.virtualbox.org/virtualbox/$VIRBOX_REL/VirtualBox-$VIRBOX_REL-$VIRBOX_SUB_REL-Win.exe -o "$CURRDIR"/VirtualBox-$VIRBOX_REL-$VIRBOX_SUB_REL-Win.exe
else
	echo "Oracle VirtualBox v. ${VIRBOX_REL}-${VIRBOX_SUB_REL} already downloaded!!"
fi
if [[ "" != "$(ls "$VBOXMAN_PATH" 2> /dev/null )" ]]; then
	echo "Any version of Oracle VirtualBox already exists. please verify verion level is 6.1.x in order to install docker!!"
	echo "Cannot unistall automatically previous Oracle VirtualBox versions. Nothing to do!!"
else
echo "Installing Oracle VirtualBox v. ${VIRBOX_REL}-${VIRBOX_SUB_REL} (silent mode)"
	"$CURRDIR"/VirtualBox-$VIRBOX_REL-$VIRBOX_SUB_REL-Win.exe --silent --logging --msiparams INSTALLDIR="$VIRBOX_PATH"
fi

if [[ "" == "$(ls "$VBOXMAN_PATH"  2> /dev/null )" ]]; then
	echo "No Oracle VirtualBox installation has been detected. Please verify verion level is 6.1.x in order to install docker!!"
	echo "Cannot continue installing VirtualBox Extension Pack v. $VIRBOX_REL then Exit!!"
	exit 1
fi

if [[ "" == "$(ls "$CURRDIR"/$EXTPACK_NAME 2> /dev/null )" ]]; then
	curl -L https://download.virtualbox.org/virtualbox/$VIRBOX_REL/$EXTPACK_NAME -o "$CURRDIR"/$EXTPACK_NAME
else
	echo "VirtualBox Extension Pack v. $VIRBOX_REL already downloaded!!"
fi
echo "Installing VirtualBox Extension Pack v. $VIRBOX_REL (just need approval)"
"$VBOXMAN_PATH" extpack install --replace "$CURRDIR"/$EXTPACK_NAME
