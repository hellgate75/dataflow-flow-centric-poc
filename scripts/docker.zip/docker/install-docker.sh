#!/bin/sh -e
CURRDIR="$(dirname "$(realpath "$0")")"
VBOXMAN_PATH="C:\\Program Files\\Oracle\\VirtualBox\\vboxmanage"
if [[ "" == "$(ls "$VBOXMAN_PATH" 2> /dev/null )" ]]; then
	echo "Please install Oracle VirtualBox v. 6.1 in order to instal docker!!"
	echo "Try with experimental script: install-virtualbox.sh"
	exit 1
fi
if [[ "" == "$(echo $PATH | grep ":$CURRDIR")" ]]; then
	PATH="$PATH:$CURRDIR"
fi
chmod +x install-docker.sh
chmod +x uninstall-docker.sh

## This function generates command files that wraps other commands that need to
## have access to docker VirtualBox bridge
function maskDockerCommand() {
    COMMAND_NAME="$1"
    MASKED_COMMAND_NAME="$2"
	echo -e "#!/bin/sh -e" > "$CURRDIR"/$COMMAND_NAME
	echo -e "CURRDIR=\"\$(dirname \"\$(realpath \"\$0\")\")\"" >> "$CURRDIR"/$COMMAND_NAME
	echo -e "if [[ \"\" == \"\$(echo \$PATH | grep \":\$CURRDIR\")\" ]]; then" >> "$CURRDIR"/$COMMAND_NAME
	echo -e "	PATH=\"\$PATH:\$CURRDIR\"" >> "$CURRDIR"/$COMMAND_NAME
	echo -e "fi" >> "$CURRDIR"/$COMMAND_NAME
	echo -e "RUNNING=\"\$(docker-machine status default| grep Running)\"" >> "$CURRDIR"/$COMMAND_NAME
	echo -e "if [[ \"\" != \"\$RUNNING\" ]]; then" >> "$CURRDIR"/$COMMAND_NAME
	echo -e "  eval \$(docker-machine-cmd.exe env --shell sh)" >> "$CURRDIR"/$COMMAND_NAME
	echo -e "fi" >> "$CURRDIR"/$COMMAND_NAME
	echo -e "$MASKED_COMMAND_NAME \$@" >> "$CURRDIR"/$COMMAND_NAME
	chmod +x "$CURRDIR"/$COMMAND_NAME
}

## This function generates command files that wraps other commands that need to
## have access to docker VirtualBox bridge
function maskSimpleCommand() {
    COMMAND_NAME="$1"
    MASKED_COMMAND_NAME="$2"
	echo -e "#!/bin/sh -e" > "$CURRDIR"/$COMMAND_NAME
	echo -e "CURRDIR=\"\$(dirname \"\$(realpath \"\$0\")\")\"" >> "$CURRDIR"/$COMMAND_NAME
	echo -e "if [[ \"\" == \"\$(echo \$PATH | grep \":\$CURRDIR\")\" ]]; then" >> "$CURRDIR"/$COMMAND_NAME
	echo -e "	PATH=\"\$PATH:\$CURRDIR\"" >> "$CURRDIR"/$COMMAND_NAME
	echo -e "fi" >> "$CURRDIR"/$COMMAND_NAME
	echo -e "$MASKED_COMMAND_NAME \$@" >> "$CURRDIR"/$COMMAND_NAME
	chmod +x "$CURRDIR"/$COMMAND_NAME
}

## Academic sample of string startsWith (any language)
function beginsWith() {                                                                                                         case $1 in
                "$2"*) echo "Y";;
                *) echo "N";;
        esac;
}
## Academic sample of path swutch between cygwin and git shell
function convertPath() {
        if [[ "Y" == "$(beginsWith $1 /cygdrive)" ]]; then
                echo "${1:9}"
        else
                echo "/cygdrive$1"
        fi
}
echo "Install Docker ..."

curl -L https://github.com/docker/machine/releases/download/v0.16.2/docker-machine-Windows-`uname -m`.exe -o "$CURRDIR"/docker-machine-cmd.exe
curl -L https://dockermsft.blob.core.windows.net/dockercontainer/docker-19-03-5.zip --output "$CURRDIR/docker-19-03-5.zip"
mkdir "$CURRDIR/tmp"
sh -c "unzip $CURRDIR/docker-19-03-5.zip -d $CURRDIR/tmp"
DOCKER_FILES="$(ls $CURRDIR/tmp/docker/|xargs echo)"
IFS=" ";for file in $DOCKER_FILES; do
     mv -f "$CURRDIR/tmp/docker/$file" "$CURRDIR/"
done
rm -Rf "$CURRDIR"/tmp
rm -f "$CURRDIR"/docker-19-03-5.zip
mv "$CURRDIR"/docker.exe "$CURRDIR"/docker-cmd.exe 2> /dev/null 
curl -L https://github.com/docker/compose/releases/download/1.25.4/docker-compose-Windows-`uname -m`.exe -o "$CURRDIR"/docker-compose-cmd.exe
if [[ "" != "$(which docker-machine-cmd.exe 2> /dev/null)" ]]; then
	if [[ "" != "$(docker-machine-cmd.exe ls | grep "default ")" ]]; then
		if [[ "" != "$(docker-machine-cmd.exe status default | grep Running)" ]]; then
				echo "Stopping default docker VirtualBox vm"
				docker-machine-cmd.exe stop default
				sleep 1
		fi
		echo "Removing default docker VirtualBox vm"
		docker-machine-cmd.exe rm -f -y default
		sleep 2
	fi
else
	echo "Command docker-machine is not present, cannot continue with installation."
	echo "Now uninstall dirty installation files ..."
	sh -c "$CURRDIR"/uninstall-docker.sh
	exit 1
fi
chmod +x "$CURRDIR"/*.exe
if [[ -e "$CURRDIR"/cli-plugins ]]; then
   chmod +x "$CURRDIR"/cli-plugins/*.exe
fi
echo "Creating default docker VirtualBox vm"
docker-machine-cmd.exe create --driver virtualbox --virtualbox-memory 4096 default
sleep 1
export do_it=0
if [[ ! -e "$CURRDIR"/data ]]; then
  sh -c "mkdir -p $CURRDIR/data"
  do_it=1
fi

echo "Stopping default docker VirtualBox vm"
"$VBOXMAN_PATH" controlvm default poweroff

if (( do_it )); then
	sleep 2
	echo "Definition of shared folder '$CURRDIR/data' -> named 'data'"
	"$VBOXMAN_PATH" sharedfolder add default --name data --hostpath "$CURRDIR"/data --automount
fi

sleep 2
echo "Starting default docker VirtualBox vm"
docker-machine-cmd.exe start

if (( do_it )); then
	sleep 2
	echo "Association of local '$CURRDIR/data' folder with (data) /mnt/data docker remote instance partition"
	docker-machine-cmd.exe ssh default "sudo mkdir -p /mnt/data"
	docker-machine-cmd.exe ssh default "sudo mount -t vboxsf data /mnt/data"
fi


echo ""
echo "Creation of environment script file: $CURRDIR/env.sh"
echo -e "#!/bin/sh -e" > "$CURRDIR"/env.sh
echo -e "CURRDIR=\"\$(dirname \"\$(realpath \"\$0\")\")\"" >> "$CURRDIR"/env.sh
echo -e "if [[ \"\" == \"\$(echo \$PATH | grep \":\$CURRDIR\")\" ]]; then" >> "$CURRDIR"/env.sh
echo -e "	PATH=\"\$PATH:\$CURRDIR\"" >> "$CURRDIR"/env.sh
echo -e "fi" >> "$CURRDIR"/env.sh
echo -e "RUNNING=\"\$(docker-machine status default| grep Running)\"" >> "$CURRDIR"/env.sh
echo -e "if [[ \"\" != \"\$RUNNING\" ]]; then" >> "$CURRDIR"/env.sh
echo -e "  eval \$(docker-machine-cmd.exe env --shell sh)" >> "$CURRDIR"/env.sh
echo -e "else" >> "$CURRDIR"/env.sh
echo -e "    echo \"Docker default vm is not running!!\"" >> "$CURRDIR"/env.sh
echo -e "fi" >> "$CURRDIR"/env.sh
chmod +x "$CURRDIR"/env.sh

echo ""
echo "Creation  of shell command: start-docker-vm"
echo -e "#!/bin/sh" > "$CURRDIR"/start-docker-vm
echo -e "CURRDIR=\"\$(dirname \"\$(realpath \"\$0\")\")\"" >> "$CURRDIR"/start-docker-vm
echo -e "if [[ \"\" != \"\$(echo \$PATH | grep \":\$CURRDIR\")\" ]]; then" >> "$CURRDIR"/start-docker-vm
echo -e "	PATH=\"\$PATH:\$CURRDIR\"" >> "$CURRDIR"/start-docker-vm
echo -e "fi" >> "$CURRDIR"/start-docker-vm
echo -e "RUNNING=\"\$(docker-machine status default| grep Running)\"" >> "$CURRDIR"/start-docker-vm
echo -e "if [[ \"\" == \"\$RUNNING\" ]]; then" >> "$CURRDIR"/start-docker-vm
echo -e "   echo \"Starting docker virtual machine ...\""
echo -e "  docker-machine start default" >> "$CURRDIR"/start-docker-vm
echo -e "  sleep 2" >> "$CURRDIR"/start-docker-vm
echo -e "  docker-machine regenerate-certs -f default"
echo -e "  eval \"$(docker-machine env)\""
echo -e "  docker-machine ssh default \"sudo mkdir -p /mnt/data\"" >> "$CURRDIR"/start-docker-vm
echo -e "  docker-machine ssh default \"if [[ \\\"\\\" = \\\"\\\$(mount|grep /mnt/data)\\\" ]]; then sudo mount -t vboxsf data /mnt/data; fi\"" >> "$CURRDIR"/start-docker-vm
echo -e "  eval \$(docker-machine-cmd.exe env --shell sh)" >> "$CURRDIR"/start-docker-vm
echo -e "else" >> "$CURRDIR"/start-docker-vm
echo -e "    echo \"Docker default vm is already running!!\"" >> "$CURRDIR"/start-docker-vm
echo -e "fi" >> "$CURRDIR"/start-docker-vm
chmod +x "$CURRDIR"/start-docker-vm

echo ""
echo "Creation of shell command: stop-docker-vm"
echo -e "#!/bin/sh" > "$CURRDIR"/stop-docker-vm
echo -e "CURRDIR=\"\$(dirname \"\$(realpath \"\$0\")\")\"" >> "$CURRDIR"/stop-docker-vm
echo -e "if [[ \"\" == \"\$(echo \$PATH | grep \":\$CURRDIR\")\" ]]; then" >> "$CURRDIR"/stop-docker-vm
echo -e "	PATH=\"\$PATH:\$CURRDIR\"" >> "$CURRDIR"/stop-docker-vm
echo -e "fi" >> "$CURRDIR"/stop-docker-vm
echo -e "RUNNING=\"\$(docker-machine status default| grep Running)\"" >> "$CURRDIR"/stop-docker-vm
echo -e "if [[ \"\" != \"\$RUNNING\" ]]; then" >> "$CURRDIR"/stop-docker-vm
echo -e "   echo \"Stopping docker virtual machine ...\""
echo -e "  eval \$(docker-machine-cmd.exe env --shell sh)" >> "$CURRDIR"/stop-docker-vm
echo -e "  docker-machine stop default" >> "$CURRDIR"/stop-docker-vm
echo -e "else" >> "$CURRDIR"/stop-docker-vm
echo -e "    echo \"Docker default vm is not running!!\"" >> "$CURRDIR"/stop-docker-vm
echo -e "fi" >> "$CURRDIR"/stop-docker-vm
chmod +x "$CURRDIR"/stop-docker-vm

echo ""
echo "Creation of shell command: status-docker-vm"
echo -e "#!/bin/sh -e" > "$CURRDIR"/status-docker-vm
echo -e "if [[ \"\" == \"\$(echo \$PATH | grep \":\$CURRDIR\")\" ]]; then" >> "$CURRDIR"/status-docker-vm
echo -e "	PATH=\"\$PATH:\$CURRDIR\"" >> "$CURRDIR"/status-docker-vm
echo -e "fi" >> "$CURRDIR"/status-docker-vm
echo -e "RUNNING=\"\$(docker-machine status default| grep Running)\"" >> "$CURRDIR"/status-docker-vm
echo -e "if [[ \"\" != \"\$RUNNING\" ]]; then" >> "$CURRDIR"/status-docker-vm
echo -e "  eval \$(docker-machine-cmd.exe env --shell sh)" >> "$CURRDIR"/status-docker-vm
echo -e "fi" >> "$CURRDIR"/status-docker-vm
echo -e "echo \"Docker default vm is \$(docker-machine status default) !!\"" >> "$CURRDIR"/status-docker-vm
chmod +x "$CURRDIR"/status-docker-vm

echo ""
echo "Creation of shell command: docker"
maskDockerCommand docker docker-cmd.exe

echo ""
echo "Creation of shell command: docker-compose"
maskDockerCommand docker-compose docker-compose-cmd.exe

echo ""
echo "Creation of shell command: docker-machine"
maskSimpleCommand docker-machine docker-machine-cmd.exe

echo "Docker installation complete!!"

if [[ -e $CURRDIR/licenses.txt ]]; then
echo ""
echo ""
echo "DOCKER LICENSE"
echo "=============="
echo ""
echo ""
sh -c "cat $CURRDIR/licenses.txt"
fi
echo ""
echo "IMPORTANT"
echo "========="
echo ""
echo "Please add '$CURRDIR' to PATH variable into your user init script,"
echo "then type 'source ~/.<initfile> <enter>'."

